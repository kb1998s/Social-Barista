


var theDate = myCalender.value.toDateString();

///// Firestore /////

const db = firebase.firestore();

const createThing = document.getElementById('createThing');
const thingsList = document.getElementById('myUL');

let thingsRef;
let unsubscribe;

auth.onAuthStateChanged(user => {

    if (user) {

        // Database Reference
        
        const db = firebase.firestore();
        thingsRef = db.collection('things');

        const userList = document.querySelector("#user-list");
        const form = document.querySelector("#add-user-form");


        //add listener to form, to create new users and avoid default form action
        form.addEventListener("submit", (e) => {

          const { serverTimestamp } = firebase.firestore.FieldValue;
          e.preventDefault();
          thingsRef.add({
            name: form.list.value,
            date: myCalender.value.toDateString(),
            uid: user.uid,
            createdAt: serverTimestamp(),
            checked: false
          });
          form.list.value = "";
        });

        //Create the users list with the firestore data
        function renderuser(doc) {

          //creating html elements
          let li = document.createElement("li");
          let name = document.createElement("span");
          let del = document.createElement("button");
          let check = document.createElement("button")
          let checked = doc.data().checked;

          //add docuemnt ID to the list element
          li.setAttribute("data-id", doc.id);
          del.setAttribute("class", "close");
          check.setAttribute("class", "close");
          if(doc.data().date === undefined){
            name.innerHTML = doc.data().name;
          }else{
            name.innerHTML = doc.data().name + "<br>" + doc.data().date;
          }
          //labels of the buttons
          // i= info and x= delete user
          del.textContent = "🗑️";
          check.textContent ="✔️";

          // add onclick action to the buttons
          del.onclick=function(){deleteUser(doc.id);}
          check.onclick=function(){checkBox(doc.id, li, check); }

          // add elements to the list element
          li.appendChild(name);
          li.appendChild(del);
          li.appendChild(check);

          if(checked == true){
            li.style.textDecoration = "line-through";
            li.style.background = "#00994C";
            li.style.color = "#fff";
            console.log('item is checked');
            check.textContent ="❌";

          }else{
            li.style.textDecoration = "";
            li.style.background = "#eee";
            li.style.color = "black";
            console.log('item is not checked');
            check.textContent ="✔️";
          }

          // add list element to the list
          userList.appendChild(li);

          
        }
          
        function deleteUser(id){
          db.collection("things")
              .doc(id)
              .delete();
        }
        function checkBox(id,li,check){
          unsubscribe = db.collection("things")
          .doc(id)
          .get()
          .then(function(doc){
            if(doc.exists){
               doc.ref.update({checked: !doc.data().checked});
               if(doc.data().checked == false){
                li.style.textDecoration = "line-through";
                li.style.background = "#00994C";
                li.style.color = "#fff";
                check.textContent ="❌";
              }
              if(doc.data().checked == true){
                li.style.textDecoration = "";
                li.style.background = "#eee"; 
                li.style.color = "black";
                check.textContent ="✔️";
              }
            }
          })
        }

        // Realtime listener
        // this function keep updated the list 
            window.getRealtimeData = function() {
          document.querySelector("#loader").style.display = "block";
          //query all users
          unsubscribe =  db.collection("things")
          .where('uid', '==', user.uid)
          .where('date', '==', myCalender.value.toDateString())
          .limit(25)
          .orderBy('createdAt')
            .onSnapshot(querySnapshot => {
              document.querySelector("#loader").style.display = "none";
              let changes = querySnapshot.docChanges();
              changes.forEach(change => {
                if (change.type === "added") {
                  //add new users to the list on fist load this create the list of existent users
                  renderuser(change.doc);
                } else if (change.type === "removed") {
                  //if an user is deleted this will remove the element of the list
                  let li = userList.querySelector(`[data-id=${CSS.escape(change.doc.id)}]`);
                  userList.removeChild(li);
                }
              });
            });
          }

          getRealtimeData();



    }else{
             // Unsubscribe when the user signs out
             unsubscribe && unsubscribe(); 
    }
});


function updateDiv()
{
  $("#user-list").load(location.href + " #user-list");
  getRealtimeData();
}