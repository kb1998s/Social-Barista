///// User Authentication /////

const auth = firebase.auth();

const whenSignedIn = document.getElementById('whenSignedIn');
const whenSignedOut = document.getElementById('whenSignedOut');

const signInBtn = document.getElementById('signInBtn');
const signOutBtn = document.getElementById('signOutBtn');

const userDetails = document.getElementById('userDetails');

const provider = new firebase.auth.GoogleAuthProvider();


/// Sign in event handlers

auth.onAuthStateChanged(user => {
    if (user) {
        // signed in
        userDetails.innerHTML = `<h3>Hello ${user.displayName}!</h3> <p>Email: ${user.email}</p> <p>User ID: ${user.uid}</p>`;
    } else {
        // not signed in
        userDetails.innerHTML = '<p>no user</p>';
    }
});