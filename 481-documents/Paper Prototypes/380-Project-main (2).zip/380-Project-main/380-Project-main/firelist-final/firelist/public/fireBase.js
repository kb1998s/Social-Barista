var fireBase = fireBase || firebase;
var hasInit = false;
var config = {
//add your own firebase config here!
  };
if(!hasInit){
  firebase.initializeApp(config);
    hasInit = true;
}


